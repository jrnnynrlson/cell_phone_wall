### Instructions

1 visit tiny.cc/cellphonewall, download slack app & turn on 'lock screen' notifications for slack

2 consider adjusting notif settings for other apps (for your own privacy)

3 select a sleeve, remove the card from it, and place your phone in the sleeve

4 an attendant will be along presently to charge :)