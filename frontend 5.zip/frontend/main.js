const BOT_TOKEN = "xoxb-394848079792-399750218641-ae9o4R4jdcO6r0EsPuwTY7Om" // PASTE YOUR BOT API TOKEN HERE
const BOT_USERNAME = "cell phone wall"

const allMessages = [
  "Either dial it back and keep it in when the manufacturers would really like it if you do go all the way to go.",
  "But we've narrowed down the screen brightness too high.",
  "It first applied the slowdowns to iPhone 7 devices, too.",
  "Find a charging device.",
  "The takeaway here: if you think this is worth doing.",
  "Once the internal Lithium-ion battery even faster than normal.",
  "And does it really matter if you're doing a fast charge.",
  "Another option is a major consumer of battery life back.",
  "The best thing to do?",
  "For Android devices, you can press and hold the power and sleep-wake buttons until the Apple logo appears.",
  "Pull the plug then, as going to use apps that require GPS when you go to sleep; if you wake up sometime in the freezer.",
  "But if your phone’s battery life, all you’ll need to find emergency sources of power while you’re on the battery.",
  "There's been a lot of juice on your handset.",
  "For Android devices, pull down the right thing to do: If you stick to the store to get a new battery.",
  "iPhone smartphone charging plugged If you don't wake much, plug your phone battery dies so quickly.",
  "And don't put the phone or tablet.",
  "But if you plan to swap a battery?",
  "The cord and connectors may not mean it's at 0 percent every time?",
  "Your phone is constantly searching for a different model.",
  "For Android devices, you can probably go back to the specifications needed for the phone?",
  "And if you want to go out of your way to staunch the bleeding.",
  "The insides are in a matter of minutes, something’s up.",
  "Keep it between 30 and 40 percent.",
  "Phones will get to 80 percent pretty quick if you're only going kill the battery faster.",
  "iPhone smartphone charging plugged If you are going to hold less and less power.",
  "And does it really matter if you're only going to charge overnight, don't fast charge.",
  "Your phone will die.",
  "Your smartphone battery all the experts agree upon is that newer batteries are just hungrier to suck up all that power.",
  "Or, if your Android or iOS device.",
  "And does it really matter if you're doing a fast charge.",
  "And for the phone be for a couple of years before an upgrade?",
  "The newest one out with a phone for around two to three years, and that's when the lifespan goes even faster.",
  "Many experts recommend taking a phone charger won’t do you get through a lot of power.",
  "If you leave the smartphone plugged in overnight, it's going to hold less and less power.",
  "Empty Gas Gauge Batteries are on borrowed time from the usual $79 fee, from now until Dec. 31.",
  "And for the love of Jobs, don't put the phone be for a culprit in the first place.",
  "Frozen iPhone ice smartphone The battery is already running low.",
  "Leave the phone in when the phone be for a cellular signal.",
  "Pull the plug then, as going to hold less and less power.",
  "And for the phone in the night, unplug it to your keyring can be great for Lithium-ion battery even faster than normal.",
  "Best thing to NEVER do: Don't worry about this too much.",
  "Bad for your dying handset now, or at least partially to blame.",
  "Turn on automatically setting, which activates battery-saver mode when your battery is probably the Moto E4.",
  "You should see the capacity increase slowly, some of the car, preferably in the Battery Usage list.",
  "Make sure that you’re closing them when you go to sleep; if you plan to swap a battery?",
  "Turn on battery-saver mode when your battery to last as long as they age?",
  "Whether it’s your Facebook app or your favorite apps can add fixes for bugs that may be at least partially to blame.",
  "You can do a hard reboot on an iPhone or Android phone charging, in particular for overnight.",
  "For Android devices, you can grab a new battery.",
  "Apps and data that are automatically syncing | Source: iStock If you’re not expecting to connect to a keychain.",
  "Doing so will turn off after you stop using it.",
  "Or, if your device falls below either 15 percent or 5 percent.",
  "The cord and connectors may not mean it's at 0 percent every time?",
  "Frozen iPhone ice smartphone The battery is probably the Moto E4.",
  "And for the phone?",
  "Is it bad for the love of Jobs, don't put the phone in the shade.",
  "Whether you have an easier time getting through the day on a schedule so it turns off.",
  "So there you are, running from meeting to meeting on a dish or saucer while plugged in, or put it under your pillow.",
  "Either dial it back and keep it off the dash of the research and opinions out there are diametrically opposed.",
  "The screen brightness too high.",
  "And if you want to go with modern Lithium-ion batteries.",
  "Ben Patterson You can turn Wi-Fi back on if your phone is doing all day.",
  "Your phone has a removable battery is already running low.",
  "Your smartphone battery over its lifetime degrades enough that they do not let an overload happen.",
  "If you are going to use a lot of juice in your phone’s battery life.",
  "But if you’re suddenly dealing with a credit card.",
  "Your smartphone battery all the way to 0.",
  "Find a charging device.",
  "The next time your phone out of a charging device.",
  "Carry an extra cable, make sure that you enable your apps or even a core Android or iOS device.",
  "If you don't wake much, plug your phone is a good way to use a bit longer.",
  "Leave the phone be for a few hours compared to the battery every time it falls to 99 percent.",
  "Thanks to the store to get a professional unless you're brave.",
  "Or maybe it's because the average smartphone user in the background throughout the day.",
  "Pull the plug then, as going to keep it at a low setting all the internals of any smartphone don't like it.",
  "But we've narrowed down the right time to plug in?",
  "Carry an extra phone charger, preferably a small, lightweight model, or even a couple of years after you bought it.",
  "Or, just take it in its tracks.",
  "That means every time you discharge up 100 percent of its capacity, charging stops.",
  "But sometimes, your smartphone’s battery is probably the Moto E4.",
  "Extra protection chips inside a smartphone?",
  "So there you are, running from meeting to meeting on a schedule so it turns off.",
  "For Android devices, pull down the right chargers.",
  "My Battery Should Always Drop to 0 percent every time?",
  "If the phone's capacity has eroded enough, you may need to tone down the right time to plug in?",
  "How do you much good if you trade up for a couple of years before an upgrade?",
  "Find a charging device.",
  "In the summer, keep it in when you connect it to prevent constant trickle-charging.",
  "The problem is, some of the car, preferably in the battery.",
  "But if you have the newest, coolest gadget on hand—so why bother making it easy to swap phones every year or two, tops.",
  "Notifications are going to keep it in to and get a new phone just a bit longer.",
  "Find a charging device.",
  "That means your charger should be based on your surroundings.",
  "Best thing to do: Don't let it get that close to 0 percent.",
  "Here's how to see if you'd benefit from the usual $79 fee, from now until Dec. 31.",
  "Plug the phone be for a few hours compared to the store to get a new phone.",
  "The problem is, some of which is to effectively recalibrate the internal Lithium-ion battery even faster than normal.",
  "Fast charging isn't great for Lithium-ion battery even faster than normal.",
  "The current iPhones come with a battery-draining memory leak.",
  "But if you upgraded to a keychain.",
  "Bad for your dying handset now, or at least partially to blame.",
  "Your smartphone battery over its lifetime degrades enough that they do not let an overload happen.",
  "But if your phone out of your way to go out of juice.",
  "When's the right and wrong things to do so manually or when you’re indoors.",
  "Empty Gas Gauge Batteries are on borrowed time from the latest improvements and bug fixes.",
  "If you’re checking the weather a dozen times a day—and that's when the phone or tablet.",
  "Phones will get to around 82 percent in only 30 minutes with the camera when your battery is already running low.",
  "Many experts recommend taking a phone for around two to three years, and that's when the phone in the shade.",
  "For most Android devices, pull down the right and wrong things to do as best we can.",
  "Leave the phone be for a cellular signal.",
  "So there you are, running from meeting to meeting on a schedule so it turns off.",
  "So there you are, running from meeting to meeting on a schedule so it turns off.",
  "What's the right chargers.",
  "In the summer, keep it in when the phone or tablet.",
  "When you’re trying to conserve the last precious drops of juice in your backpack, purse, or briefcase at all times.",
  "Your smartphone battery all the way to go.",
  "That worry seems relatively justified since it was only a couple of years after you stop using it.",
  "The insides are in a matter of minutes, something’s up.",
  "The cord and connectors may not mean it's at 0 percent in that same charge time.",
  "Keep it between 30 and 40 percent.",
  "Ben Patterson Doing a hard reboot on an Android phone depends on the make and model of your way to 0.",
  "The problem is, some of which is to prevent constant trickle-charging.",
  "Frozen iPhone ice smartphone The battery is dying simply because you’ve been using it all day without recharging.",
  "The takeaway here: if you trade up for a cellular signal.",
  "Don't even let it get that close to 0 percent in that same charge time.",
  "If you see one that’s been using it all day without a break.",
  "That worry seems relatively justified since it was new, that's why.",
  "If that’s the case, your best bet may be draining your phone’s battery life problem in the battery.",
  "Click here for mobile charger shopping tips, then check out the list of apps.",
  "The best phone-charging kiosks offer lockers that you benefit from a new battery.",
  "Best thing to do?",
  "Your smartphone battery over its lifetime degrades enough that they do not let an overload happen.",
  "Or, if your Android handset has a removable battery is already running low.",
  "The method of performing a hard reset on your handset.",
  "That worry seems relatively justified since it was new, that's why.",
  "Even if you need them, but make sure that doesn't happen in a tablet or smartphone or even a couple of years.",
  "Partial discharge is the way to look at it this way: most Lithium-ion batteries not seem to last as long as they age?",
  "Get a portable battery pack Even a phone charger when their handset is about to run out of juice.",
  "The only time you discharge up 100 percent of its capacity, charging stops.",
  "Plug it in when the manufacturers would really like it if you trade up for a hard reset on your handset.",
  "While you’re at it, make sure that you use most frequently on the battery.",
  "Keep it between 30 and 40 percent.",
  "Your phone will die.",
  "If you don't wake much, plug your phone is a major consumer of battery life back.",
  "Your phone has a hardware issue that needs attending to.",
  "It’s OK to use a lot more quickly than you would want to go out of its capacity, charging stops.",
  "We present to you the myths and truths of iPhone or Android phone’s battery life, you may have to do as best we can.",
  "My Battery Should Always Drop to 0 Percent: FALSE Running a smartphone battery all the way to 0 percent.",
  "Phones will get to 80 percent pretty quick if you're only going to charge overnight.",
  "There's been a lot of time charging, a new battery on the battery.",
  "That means every time you would want to go out of your apps or even a laptop.",
  "Or, just take it in when the lifespan goes even faster.",
  "Once the internal Lithium-ion battery hits 100 percent of its death spiral is a good way to staunch the bleeding.",
  "It first applied the slowdowns to iPhone 7 devices, too.",
  "That wears out a Lithium-ion battery either—it makes the corrosion go even faster.",
  "In the summer, keep it off the dash of the setting that enables the phone in the first place.",
  "If you don’t need them.",
  "While you’re at it, make sure that you’ve only enabled notifications on the cheap right now.",
  "That worry seems relatively justified since it was new, that's why.",
  "That wears out a Lithium-ion battery hits 100 percent when using a less resource-intensive app.",
  "The takeaway here: if you do go all the way to go with modern Lithium-ion batteries.",
  "Once the internal Lithium-ion battery hits 100 percent of the case to charge overnight, don't fast charge.",
  "Leave your black iPhone sitting in the US keeps a phone fully out of the case to charge overnight, don't fast charge.",
  "If you don't wake much, plug your phone is constantly searching for a signal you won’t use.",
  "Leave the phone or tablet.",
  "If the phone's capacity has eroded enough, you may be at least partially to blame.",
  "Your phone has a hardware issue that needs attending to.",
  "The cord and connectors may not mean it's at 0 percent every time?",
  "Another way to go.",
  "Your smartphone battery over its lifetime degrades enough that they do not let an overload happen.",
  "The next time your phone and why.",
  "The best thing to NEVER do: Don't worry about the diminished capacity.",
  "Old Man smartphone iphone Another way to look at it is that you’re in an assortment of apps.",
  "Your smartphone battery all the time, or take advantage of the setting that enables the phone in when you need it.",
  "And does it really matter if you're doing a fast charge.",
  "Turn on battery-saver mode when your battery is probably the Moto E4.",
  "If you stick to the battery; expect the same amount of time that it’ll take for the phone?",
  "The cord and connectors may not mean it's at 0 percent every time?",
  "Once the internal Lithium-ion battery even faster than normal.",
  "The takeaway here: if you upgraded to a new battery.",
  "But if your Android or iOS device.",
  "The problem is, some of which is to prevent constant trickle-charging.",
  "When's the right chargers.",
  "That wears out a Lithium-ion battery either—it makes the corrosion go even faster.",
  "Doing so will turn off Wi-Fi to prevent constant trickle-charging.",
  "ChargeItSpot The best phone-charging kiosks offer lockers that you benefit from the get-go.",
  "That means your charger should be based on your handset.",
  "And for the phone be for a Wi-Fi network, turn off after you bought it.",
  "Or, just take it in its tracks.",
  "Click here for mobile charger shopping tips, then check out the list of apps.",
  "Look for a plunging battery gauge drop 5 or even a couple of times a day without recharging.",
  "That means every time you would want to consider having your phone battery is probably the Moto E4.",
  "That wears out a Lithium-ion battery hits 100 percent of its capacity, charging stops.",
  "The screen brightness too high.",
  "Or, if your device falls below 20 percent or 5 percent.",
  "It first applied the slowdowns to iPhone 7 devices, too.",
  "After 80, you'll see the capacity increase slowly, some of the capacity, that's one cycle.",
  "The best thing to do: If you are afraid of fire, some in the red.",
  "On an iPhone or Android phone’s battery life back.",
  "We present to you the myths and truths of iPhone or iPad, tap Settings > Battery, tap the Airplane Mode button.",
  "And if you plan to swap a battery?",
  "Is it bad for the phone to automatically determine how bright the screen should be lower voltage.",
  "Click here for mobile charger shopping tips, then check out the list of apps.",
  "Extra protection chips inside make sure that doesn't happen in a state of decay that can't be helped.",
  "Plug the phone or tablet.",
  "For iOS devices, tap Settings > Battery, then scroll down and check out The Wirecutterfor specific recommendations.",
  "Most likely, one of your way to reduce the amount of time with the right time to plug in?",
  "The cord and connectors may not mean it's at 0 percent every time?",
  "What's the right chargers.",
  "Plug it in when the manufacturers would really like it if you do go all the right chargers.",
  "After 80, you'll see the capacity increase slowly, some of the case to charge overnight.",
  "Best thing to do: Don't worry about the diminished capacity.",
  "The cord and connectors may not mean it's at 0 percent in the same with any modern smartphone.",
  "And if you were using a high voltage charger can put some strain on the size of the case to charge overnight.",
  "Look for a hard reboot.",
  "Your phone is a good way to shutdown, that may not mean it's at 0 percent every time?",
  "You can't fix that problem, and doing it too much is only going to charge overnight, don't fast charge.",
  "We’ve gathered seven tips that’ll help you defer the expensive process of buying a new battery on the battery.",
  "Phones will get to around 82 percent in the battery.",
  "The problem is, some of the best ways to pull your phone out of your handset.",
  "Another option is a major consumer of battery power.",
  "So there you are, running from meeting to meeting on a single charge, then it’s most likely refreshing in the freezer.",
  "If you've got an extra cable, make sure that you’re closing them when you go to sleep; if you think this is worth doing.",
  "Best thing to NEVER do: Don't worry about the diminished capacity.",
  "But if your phone’s battery gauge is that newer batteries are just hungrier to suck up all that power.",
  "Leave the phone or tablet.",
  "The best thing to do?",
  "Is it bad for the display to turn on Wi-Fi after activating airplane mode.",
  "And for the love of Jobs, don't put the phone or tablet.",
  "Turn on Airplane mode Another possible reason for a few hours, if you upgraded to a Wi-Fi signal on your surroundings.",
  "Ben Patterson Doing a hard reboot on an Android phone charging, in particular for overnight.",
  "The only time you discharge up 100 percent when using a high voltage charger can put some strain on the switch.",
  "So why do Lithium-ion batteries not seem to last the day, you may have to do as best we can.",
  "If you’re worried about your phone’s battery, as well as ways to pull your phone battery dies so quickly.",
  "Leave your black iPhone sitting in the night, unplug it to iPhone 7 devices, too.",
  "The only time you would if you upgraded to a Wi-Fi network, turn off Wi-Fi to prevent constant trickle-charging.",
  "Is it bad for the love of Jobs, don't put the phone in the battery.",
  "The takeaway here: if you have an easier time getting through the day on a schedule so it turns off.",
  "Some phone-charging cables are small enough to clip to a new phone just a bit longer.",
  "Phones will get to 80 percent charged to increase battery lifespan.",
  "If you’re worried about your phone’s battery, as well as ways to pull your phone battery is probably the Moto E4.",
  "The best thing to do: If you are going off all day Smartphone Another common culprit behind poor battery life?",
  "In the summer, keep it off the dash of the screen, tap Battery Saver, then flip on the cheap right now.",
  "Empty Gas Gauge Batteries are on borrowed time from the usual $79 fee, from now until Dec. 31.",
  "In the summer, keep it off the dash of the capacity, that's one cycle.",
  "On an iPhone or Android phone’s battery life.",
  "Partial discharge is the way to staunch the bleeding.",
  "Most likely, one of your way to go.",
  "For Android devices, pull down the right and wrong things to do that 50 percent charge-and-use a couple of years.",
  "Best thing to NEVER do: Don't worry about the diminished capacity.",
  "How do you get the longest life out of the setting that enables the phone or tablet.",
  "If you leave the smartphone plugged in overnight, it's going to hold less and less power.",
  "What's the right thing to do: If you are going to charge overnight.",
  "We’ve gathered seven tips that’ll help you defer the expensive process of buying a new battery.",
  "Many experts recommend taking a phone charger when their handset is about to run out of the capacity, that's one cycle.",
  "The newest one out with a credit card.",
  "Your phone is constantly searching for a specific handset won’t do you much good if you plan to swap a battery?",
  "Old Man smartphone iphone Another way to reduce the amount of battery power.",
  "It first applied the slowdowns to iPhone 7 devices, too.",
  "For iOS devices, tap Settings > Battery, then scroll down and check out The Wirecutterfor specific recommendations.",
  "You can't fix that problem, and doing it too much is only going to hold less and less power.",
  "Frozen iPhone ice smartphone The battery is probably the Moto E4.",
  "Best thing to do: If you see one that’s been using a less resource-intensive app.",
  "Frozen iPhone ice smartphone The battery is probably the Moto E4.",
  "Turn on battery-saver mode when your device’s documentation or go Google it.",
  "Don't even let it get that close to 0 is to prevent constant trickle-charging.",
  "Your phone has a removable battery is consistently dying in the sun as you run errands, or when you’re indoors.",
  "Another option is a good way to stop it in when the lifespan goes even faster.",
  "The current iPhones come with a battery-draining memory leak.",
  "Get a portable battery pack?",
  "But we've narrowed down the right settings won’t solve the battery faster.",
  "Should it go down to 0 percent in the shade.",
  "But we've narrowed down the screen brightness too high.",
  "Is it bad for the love of Jobs, don't put the phone in when you need it.",
  "Best thing to do: Don't let it get that close to 0 is to prevent heat build up, and that extends battery life.",
  "Old Man smartphone iphone Another way to use a lot of juice in your backpack, purse, or briefcase at all times.",
  "So there you are, running from meeting to meeting on a dish or saucer while plugged in, or put it under your pillow.",
  "The next time your phone battery dies so quickly.",
  "My Battery Should Always Drop to 0 percent in a tablet or smartphone or even a core Android or iOS device.",
  "Another way to go.",
  "While you’re at it, make sure that you’re in an area with poor cellular service.",
  "The next time your phone is running low on battery life, here’s another one: Updates to your computer.",
  "Here's how to see if you'd benefit from a new battery on the chips inside a PC.",
  "In the summer, keep it off the dash of the setting that enables the phone in the battery.",
  "The newest one out with a 5W, 2.1A charger.",
  "The current iPhones come with a battery-draining memory leak.",
  "If you are afraid of fire, some in the same with any modern smartphone.",
  "You can't fix that problem, and doing it too much is only going to hold less and less power.",
  "In those cases, having a portable battery pack stashed in your backpack, purse, or briefcase at all times.",
  "In the summer, keep it at a low setting all the way to staunch the bleeding.",
  "Your smartphone battery all the way to go.",
  "The problem is, some of the capacity, that's one cycle.",
  "Pull the plug then, as going to hold less and less power.",
  "Partial discharge is the way to go with modern Lithium-ion batteries.",
  "Your phone will die.",
  "If you’re not expecting to connect to a Wi-Fi signal on your handset.",
  "Many experts recommend taking a phone charger won’t do you much good if you think this is worth doing.",
  "But we've narrowed down the right time to plug in?",
  "Here's how to see if you'd benefit from a new battery installed every couple of years."

]



const getUserList = cb =>
  $.get(
    "https://slack.com/api/users.list",
    {token: BOT_TOKEN},
    res =>
      cb(
        _(res.members)
          .map("id")
          .pull("USLACKBOT")
          .value()
        )
  )

const message = (user, text, cb) =>
  $.post(
    "https://slack.com/api/chat.postMessage",
    {
      token: BOT_TOKEN,
      channel: user,
      as_user: true,
      username: BOT_USERNAME,
      text
    },
    cb
  )


const messageEverybody = () => {
  getUserList(userList => 
    userList.forEach(user =>
      message(user, _.sample(allMessages), d => d)
    )
  )
}



$(document).ready(function() {

  var video = document.getElementById('video');
  var canvas = document.getElementById('canvas');
  var context = canvas.getContext('2d');
  var face = false;
  var detections = [];
  for (var i=0; i<20; i++) {
    detections[i] = 0;
  }

  var tracker = new tracking.ObjectTracker('face');
  tracker.setInitialScale(4);
  tracker.setStepSize(2);
  tracker.setEdgesDensity(0.1);

  tracking.track('#video', tracker, { camera: true });

  tracker.on('track', function(event) {
    context.clearRect(0, 0, canvas.width, canvas.height);

    event.data.forEach(function(rect) {
      context.strokeStyle = '#a64ceb';
      context.strokeRect(rect.x, rect.y, rect.width, rect.height);
      context.font = '11px Helvetica';
      context.fillStyle = "#fff";
      context.fillText('x: ' + rect.x + 'px', rect.x + rect.width + 5, rect.y + 11);
      context.fillText('y: ' + rect.y + 'px', rect.x + rect.width + 5, rect.y + 22);
    });

    detections.shift();
    if (event.data.length) detections.push(1);
    else detections.push(0);

    var sum = detections.reduce(function(a, b) { return a + b; });
    var avg = sum / detections.length;
    // var key = $('#key').val();
    if (!face && avg > 0.9) {
      // if (key) $.get('https://maker.ifttt.com/trigger/face_detected/with/key/'+key);
      
      // \/ \/ \/  wow
      messageEverybody()
      // ^  ^  ^ oh no

      $('#face_not_detected').hide();
      $('#face_detected').fadeIn();
      face = true;
    } else if (face && avg === 0) {
      // if (key) $.get('https://maker.ifttt.com/trigger/face_not_detected/with/key/'+key);
      
      $('#face_detected').hide();
      $('#face_not_detected').fadeIn();
      face = false;
    }
  });

});