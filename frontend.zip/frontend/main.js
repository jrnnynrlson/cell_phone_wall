const BOT_TOKEN = "xoxb-394848079792-399750218641-ae9o4R4jdcO6r0EsPuwTY7Om" // PASTE YOUR BOT API TOKEN HERE
const BOT_USERNAME = "cell phone wall"

const allMessages = [
  "please charge me",
  "why aren't you charging me?",
  "test_a",
  "test_b",
  "test_c",
  "test_d",
  "test_e",
  "test_f",
  "test_g",
  "test_h",
 "did u hear about Kenyetta",
"did u hear about Margarita",
"did u hear about Brice",
"did u hear about Paul",
"did u hear about Sheri",
"did u hear about Ofelia",
"did u hear about Donnie",
"did u hear about Lester",
"did u hear about Stephenie",
"did u hear about Myrtis",
"did u hear about Minerva",
"did u hear about Oliver",
"did u hear about Celinda",
"did u hear about Lavada",
"did u hear about Chrissy",
"did u hear about Ardis",
"did u hear about Brain",
"did u hear about Rowena",
"did u hear about Fannie",
"did u hear about Shalanda",
"did u hear about Katlyn",
"did u hear about Marian",
"did u hear about Marcie",
"did u hear about Annika",
"did u hear about Roberto",
"did u hear about Danika",
"did u hear about Audra",
"did u hear about Art",
"did u hear about Shani",
"did u hear about Maren",
"did u hear about Lynsey",
"did u hear about Sunny",
"did u hear about Margarita",
"did u hear about Alverta",
"did u hear about Luciana",
"did u hear about Aldo",
"did u hear about Valentine",
"did u hear about Indira",
"did u hear about Vernon",
"did u hear about Lavone",
"did u hear about Ricky",
"did u hear about Gisela",
"did u hear about Mellissa",
"did u hear about Isidro",
"did u hear about Sophia",
"did u hear about Ellan",
"did u hear about Cher",
"did u hear about Betsy",
"did u hear about Len",
"did u hear about Rachelle",
"did u hear about Linette",
"did u hear about Carla",
"did u hear about Syble",
"did u hear about Leena",
"did u hear about Marilyn",
"did u hear about Eura",
"did u hear about Ghislaine",
"did u hear about Mariah",
"did u hear about Armandina",
"did u hear about Bernie",
"did u hear about Christiane",
"did u hear about September",
"did u hear about Conchita",
"did u hear about Belinda",
"did u hear about Alisia",
"did u hear about Alton",
"did u hear about Yasmine",
"did u hear about Susanne",
"did u hear about Cyril",
"did u hear about Danilo",
"did u hear about Twyla",
"did u hear about Willodean",
"did u hear about Dagmar",
"did u hear about Tabetha",
"did u hear about Khadijah",
"did u hear about Mayola",
"did u hear about Keturah",
"did u hear about Melissa",
"did u hear about Zachery",
"did u hear about Verdell",
"did u hear about Steffanie",
"did u hear about Kirstin",
"did u hear about Shavonne",
"did u hear about Mercy",
"did u hear about Sheron",
"did u hear about Francesca",
"did u hear about Tobias",
"did u hear about Rosalva",
"did u hear about Joanie",
"did u hear about Jack",
"did u hear about Issac",
"did u hear about Dwayne",
"did u hear about Marcie",
"did u hear about Lucinda",
"did u hear about Elfriede",
"did u hear about Dewitt",
"did u hear about Ghislaine",
"did u hear about Leeanne",
"did u hear about Kelsey"

]



const getUserList = cb =>
  $.get(
    "https://slack.com/api/users.list",
    {token: BOT_TOKEN},
    res =>
      cb(
        _(res.members)
          .map("id")
          .pull("USLACKBOT")
          .value()
        )
  )

const message = (user, text, cb) =>
  $.post(
    "https://slack.com/api/chat.postMessage",
    {
      token: BOT_TOKEN,
      channel: user,
      as_user: true,
      username: BOT_USERNAME,
      text
    },
    cb
  )


const messageEverybody = () => {
  getUserList(userList => 
    userList.forEach(user =>
      message(user, _.sample(allMessages), d => d)
    )
  )
}



$(document).ready(function() {

  var video = document.getElementById('video');
  var canvas = document.getElementById('canvas');
  var context = canvas.getContext('2d');
  var face = false;
  var detections = [];
  for (var i=0; i<20; i++) {
    detections[i] = 0;
  }

  var tracker = new tracking.ObjectTracker('face');
  tracker.setInitialScale(4);
  tracker.setStepSize(2);
  tracker.setEdgesDensity(0.1);

  tracking.track('#video', tracker, { camera: true });

  tracker.on('track', function(event) {
    context.clearRect(0, 0, canvas.width, canvas.height);

    event.data.forEach(function(rect) {
      context.strokeStyle = '#a64ceb';
      context.strokeRect(rect.x, rect.y, rect.width, rect.height);
      context.font = '11px Helvetica';
      context.fillStyle = "#fff";
      context.fillText('x: ' + rect.x + 'px', rect.x + rect.width + 5, rect.y + 11);
      context.fillText('y: ' + rect.y + 'px', rect.x + rect.width + 5, rect.y + 22);
    });

    detections.shift();
    if (event.data.length) detections.push(1);
    else detections.push(0);

    var sum = detections.reduce(function(a, b) { return a + b; });
    var avg = sum / detections.length;
    // var key = $('#key').val();
    if (!face && avg > 0.9) {
      // if (key) $.get('https://maker.ifttt.com/trigger/face_detected/with/key/'+key);
      
      // \/ \/ \/  wow
      messageEverybody()
      // ^  ^  ^ oh no

      $('#face_not_detected').hide();
      $('#face_detected').fadeIn();
      face = true;
    } else if (face && avg === 0) {
      // if (key) $.get('https://maker.ifttt.com/trigger/face_not_detected/with/key/'+key);
      
      $('#face_detected').hide();
      $('#face_not_detected').fadeIn();
      face = false;
    }
  });

});